Sharp Two-Contrast Gardner Bounds and a Trace-Norm Defect
Sami Abdullah Abed, Irina Nikolaeva, Andrej Novikov

Working English draft prepared for consideration of Mathematical Notes.
This source archive contains one self-contained paper.tex; the bibliography is inline.
Compile with: latexmk -pdf -interaction=nonstopmode -halt-on-error paper.tex
Requirements: standard TeX Live, article, AMS packages, geometry, hyperref, Latin Modern (lmodern).

The PDF has 9 pages in a general 11pt article/letter layout. Compliance with the
journal's current language, length and formatting rules has not been verified.
The document includes the known author affiliations, correspondence email and
substantive AI-assistance disclosure. Unknown author metadata are not invented.
The full proofs of the two-contrast Gardner bound and trace-norm defect remain.
This is a focused version of the fuller Gardner manuscript in the project.
