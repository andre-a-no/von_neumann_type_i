**Publication draft: Connes–Størmer entropy of two MASAs. Prepared 3 November 2026.**

**NYJM initial-submission preparation, 3 November 2026.**

The manuscript follows the user-supplied NYJM instructions for an initial PDF submission: the existing
11-point A4 article layout is retained. No `nyjm.cls` file has been fabricated or substituted; the
journal-specific class and final letter-paper preparation belong to the post-acceptance stage specified
in those instructions. Keywords and MSC2020 classifications are retained. The title spells out the
two-by-two matrix algebra and the abstract is plain prose, without displayed formulas or inline mathematical
symbols. PDF title metadata is aligned with the revised title.

The manuscript now declares the actual AI assistance: drafting/restructuring, research exploration and
development of mathematical arguments including the genericity proof, and development/execution of numerical
and exact-verification programs. The declaration states human responsibility normatively. It does not assert
that the human authors have already independently verified, approved or submitted the AI-assisted material.
No affiliations, funding or approval records have been invented. The coordinating agent prepares the matching
email disclosure separately; no email or submission has been sent by this task.

This directory contains a full English manuscript, not a submission record. `paper.tex` is the entry point;
`introduction.tex`, `discussion.tex`, `references.tex`, `generated/connes_stormer.tex` and the four figure PDFs
are local inputs. The manuscript can be compiled independently from this directory:

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error paper.tex
```

Authors remain Irina Nikolaeva and Andrej Novikov, as in the source. Andrej Novikov and
`a.hobukob@gmail.com` were explicitly confirmed by the user as the correspondence contact for NYJM.
No affiliations, acknowledgements, funding, referee identities or submission claims have been invented.
No journal submission has been made.

The user subsequently supplied the affiliations: **Lean Technologies Laboratory LLC** for Irina Nikolaeva
and **Novikov Laboratories LLC** for Andrej Novikov. These names are now displayed with the authors and
used in the draft submission letter. Postal addresses, country/city and funding status have not been inferred.

**Source and editorial work.**

- Proof core: `man/connes_stormer/connes_stormer_masas.tex` in the repository at revision `d257f61`.
  The original source remains unchanged.
- The title and abstract now centre the proved M₂ result. The introduction is newly written around the
  unrestricted partition problem, the precise contribution relative to Petz–Szántó–Weiner, and the
  distinction between the qubit theorem and higher-dimensional searches.
- A new discussion/conclusion explains the mechanism, asymptotics, and what would be required to turn
  the higher-dimensional conjectures into theorems.
- All original core proofs are retained: ensemble/concave-envelope representation; antipodal symmetry;
  reduction to a pure state in the measurement plane; the sliding-window formula and unique optimal
  angle; the cubic small-angle expansion; and the first-order improvement criterion in arbitrary n.
- The moving-window proof now explicitly handles a window meeting no positive hump of ψ.
- The higher-dimensional search values use hats where possible. Several residual categorical phrases
  in the original were narrowed: agreement of searches does not prove basis optimality; a searched
  state value above a searched partition value does not prove the exact gap H<G*; and an explicit
  partition beating all found bases does not prove superiority over every basis.
- The historical numerical figure retains its original axis labels; its new caption explicitly says
  that H on that graphic denotes a searched partition value, not a certified global entropy.
- The bibliography is a local, trimmed copy of the cited entries in the source. No references or
  bibliographic metadata have been invented; the unneeded recent Ghosh–Kumar entry is not included.
  A fresh external literature/metadata audit has not been performed.

**Numerical provenance.**

`generated/connes_stormer.json`, `generated/connes_stormer.tex` and the four figures are copied from the
existing research output. The recorded research revision is `e8d5873`, full mode, CPU. These data have not
been regenerated after the library's numerical corrections. The copy of the JSON is included to make the
source data available alongside the article; it is not loaded by LaTeX.

The analytical formula and the analytic theorem statements have proofs in the manuscript. The historical data for n=3,4,5
remain numerical observations without interval enclosures and without global upper certificates for
the basis or partition optimisations. The historical 50-digit recomputation is not a rigorous numerical
certificate. New, separately stored attempts and pointwise bounds were then added as described below.

**Further questions actually attempted.**

1. **Almost-everywhere first-order non-optimality: resolved analytically.** `genericity.tex` proves that the
   nonzero-entry domain in U(n) is connected (coordinate-zero loci are smooth real codimension two), then applies
   a proved real-analytic zero-set lemma to the nontrivial skew-Hermitian part of M_U. Together with the existing
   first-order criterion this establishes H>h(U) for Haar-almost every unitary in every n>=2. The coordinating
   agent independently checked the proof. This does not establish H<G* or superiority of nonorthogonal partitions.
2. **Historical largest-gap U and partition: provenance limitation found.** The historical JSON stores U for
   sample 109 but not its maximizing partition vectors/free Z. The historical partition cannot be extracted
   from that summary. We reconstructed a new four-effect frame by an independent implementation instead.
3. **Basis-vs-partition: actual independent bounded searches.** `attempts/explore_basis_gap.py` uses direct
   NumPy/SciPy entropy objectives, a six-parameter CKM basis and a complex-Givens U4 frame. The final campaign has
   64 basis starts (seed 20261103, cap1200 iterations/start) and 32 frame starts (seed20261104, cap1500).
   Its recorded best values are approximately .565919750582 and .572778446637. A separate initial polar-target
   campaign is retained; final logs identify the exact rational target used afterwards. Analytic gradient checks
   against central finite differences had errors below3e-10. These searches remain local.
4. **Lower-bound half: completed finite point verification.** `attempts/certify_points.py` reconstructs exact
   Gaussian-rational Cayley matrices, verifies unitarity and the Parseval-frame identity, and encloses scalar
   entropies with Arb at256bits. It proves H(U0)>.572778446636, encloses one basis value between
   .565919750582 and .565919750583, and gives an exact point gap >.006858696053. It also encloses one state value
   above .754681285291. This is a new rational U0 seeded by the historical sample, not a claim that its rounded
   historical matrix is exactly unitary. The basis upper endpoint applies only to that basis, not all bases.
5. **Global upper-bound half: attempted and not closed.** The independent exploratory continuity cover performs
   10000splits/20001center evaluations and leaves the universal cap at log3. Its floating centers are not Arb
   certificates. A proved continuity modulus quantifies why this crude uniform approach is inadequate:
   covering at the approximately .00686 gap scale needs about3.44e26 Cartesian cells. This is not a lower bound
   for every possible adaptive proof. The remaining mathematical obstacle is a genuinely global basis upper bound.

The old eight-item wish list was removed from the article; the article now reports these actual results,
experiments and obstructions. The unattempted directions in the old source remain in that unchanged source,
rather than being presented as work done here.

**Readiness limits.**

- The complete qubit theorem is written as a variational formula, not an elementary closed form.
- The entire historical higher-dimensional survey still needs rerunning against the corrected clean software revision
  before being presented as validation of that revision.
- A globally certified comparison for one higher-dimensional unitary and an independent proof/literature
  review remain desirable before journal submission. Neither is claimed by this manuscript build.
- Full author/institutional and submission-specific declarations need to be supplied by the authors.

**Build checks.** The independent local build produces a 23-page A4 PDF with the original 13 proved results
and six additional proved lemma/theorem/proposition statements, 24 cited bibliography entries and four figures.
There are no undefined references
or citations and no overfull boxes; one reference paragraph gives a harmless underfull-box notice. All
project-specific TeX/figure dependencies are local. The first page was visually inspected. Historical JSON
and generated TeX copies are byte-identical to their source versions.

SHA-256 of the JSON: `f5a3feeefd5d91ace6613ba9336417e3f75f4ae60fe3fb80b8c168f85829fc8d`.
SHA-256 of the generated TeX: `96c0d88e4af1116f814646ad78ea8b4b1d27cd0a06b1849dbbb497117a00d649`.

The new exact point checker refuses optimized Python (`-O` or `-OO`), so its admissibility assertions cannot
be bypassed by that interpreter setting. Default replay and the optimized-interpreter rejection were checked.
`attempts/checker_sha256.txt` records the final checker hash; `attempts/negative_checks.json` includes the rejection.

`build-console.txt` and `paper.log` record the local TeX build. `paper.txt` and `cover.png` are validation
artifacts, not additional manuscript inputs; they can be excluded from a source upload.
