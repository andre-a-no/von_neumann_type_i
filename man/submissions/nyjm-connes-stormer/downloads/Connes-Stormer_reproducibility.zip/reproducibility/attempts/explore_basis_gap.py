"""Bounded independent NumPy/SciPy attempts; none of these floating-point bounds is a certificate."""
from pathlib import Path
import argparse
import heapq
import json
import math
import platform
import time
from datetime import datetime, timezone

import numpy as np
import scipy
from scipy.optimize import minimize, brentq
from scipy.special import xlogy


def entropy_entries(p):
    return -np.sum(xlogy(p, p))


def rotation(n, i, j, theta, phase):
    c, s, z = np.cos(theta), np.sin(theta), np.exp(1j * phase)
    g = np.eye(n, dtype=complex)
    gt = np.zeros((n, n), dtype=complex)
    gp = np.zeros((n, n), dtype=complex)
    g[i, i] = g[j, j] = c
    g[i, j], g[j, i] = -s * z.conjugate(), s * z
    gt[i, i] = gt[j, j] = -s
    gt[i, j], gt[j, i] = -c * z.conjugate(), c * z
    gp[i, j], gp[j, i] = 1j * s * z.conjugate(), 1j * s * z
    return g, gt, gp


def product_with_derivatives(factors, derivatives):
    n = factors[0].shape[0]
    pre, post = [np.eye(n, dtype=complex)], [None] * (len(factors) + 1)
    for factor in factors:
        pre.append(pre[-1] @ factor)
    post[-1] = np.eye(n, dtype=complex)
    for i in range(len(factors) - 1, -1, -1):
        post[i] = factors[i] @ post[i + 1]
    return pre[-1], [pre[i] @ d @ post[i + 1] for i, d in derivatives]


def basis(x):
    # CKM form: diag(e^{i phi1},e^{i phi2},1) R23 R13(delta) R12.
    a, b, c, delta, phi1, phi2 = x
    r23, t23, _ = rotation(3, 1, 2, b, 0)
    r13, t13, p13 = rotation(3, 0, 2, c, delta)
    r12, t12, _ = rotation(3, 0, 1, a, 0)
    d = np.diag([np.exp(1j * phi1), np.exp(1j * phi2), 1])
    d1, d2 = np.zeros((3, 3), complex), np.zeros((3, 3), complex)
    d1[0, 0], d2[1, 1] = 1j * d[0, 0], 1j * d[1, 1]
    return product_with_derivatives([d, r23, r13, r12],
                                    [(3, t12), (1, t23), (2, t13), (2, p13), (0, d1), (0, d2)])


def frame(x):
    # Complex QR elimination mesh for U(4), modulo its irrelevant column phases.
    pairs = [(2, 3), (1, 2), (0, 1), (2, 3), (1, 2), (2, 3)]
    factors, dt, dp = [], [], []
    for k, (i, j) in enumerate(pairs):
        g, gt, gp = rotation(4, i, j, x[k], x[6 + k])
        factors.append(g)
        dt.append((k, gt))
        dp.append((k, gp))
    w, dw = product_with_derivatives(factors, dt + dp)
    return w[:3], [d[:3] for d in dw]


def objective(x, U, parameterization):
    w, dw = parameterization(x)
    z = U.conj().T @ w
    p, q = np.abs(w) ** 2, np.abs(z) ** 2
    value = (entropy_entries(q) - entropy_entries(p)) / 3
    lp, lq = 1 + np.log(np.maximum(p, 1e-300)), 1 + np.log(np.maximum(q, 1e-300))
    grad = np.array([2 * np.real(np.sum(lp * w.conj() * d)
                                - np.sum(lq * z.conj() * (U.conj().T @ d))) / 3 for d in dw])
    return -float(value), -grad


def serial_matrix(a):
    return {"real": a.real.tolist(), "imag": a.imag.tolist()}


def multi(U, parameterization, starts, seed, maxiter):
    rng = np.random.default_rng(seed)
    k = 3 if parameterization is basis else 6
    bounds = [(0., math.pi / 2)] * k + [(0., 2 * math.pi)] * k
    best, best_x, rows, t0 = -np.inf, None, [], time.perf_counter()
    for j in range(starts):
        x = np.array([rng.uniform(lo, hi) for lo, hi in bounds])
        fit = minimize(objective, x, args=(U, parameterization), jac=True, method="L-BFGS-B", bounds=bounds,
                       options={"maxiter": maxiter, "ftol": 1e-14, "gtol": 2e-9, "maxls": 40})
        value = -float(fit.fun)
        if value > best:
            best, best_x = value, fit.x.copy()
        rows.append({"start": j, "value": value, "success": bool(fit.success), "nit": int(fit.nit),
                     "nfev": int(fit.nfev), "message": str(fit.message)})
    w, _ = parameterization(best_x)
    return {"best": best, "parameters": best_x.tolist(), "matrix": serial_matrix(w), "starts": starts,
            "seed": seed, "maxiter": maxiter, "seconds": time.perf_counter() - t0, "runs": rows,
            "row_isometry_residual": float(np.linalg.norm(w @ w.conj().T - np.eye(3))),
            "total_function_evaluations": sum(x['nfev'] for x in rows)}


def omega(t, n=3):
    if t <= 0:
        return 0.
    if t >= 1 - 1 / n:
        return math.log(n)
    return -t * math.log(t) - (1 - t) * math.log1p(-t) + t * math.log(n - 1)


def exploratory_cover(U, splits):
    """Floating center/radius exploration; the only rigorous cap used is universal log(3)."""
    root = np.array([(0., math.pi / 2)] * 3 + [(0., 2 * math.pi)] * 3)
    queue, counter, evaluations = [], 0, 0
    best = -np.inf
    radii = []

    def add(box, depth):
        nonlocal counter, evaluations, best
        center = np.mean(box, axis=1)
        value = -objective(center, U, basis)[0]
        radius = float(np.sum((box[:, 1] - box[:, 0]) / 2))
        heuristic = min(math.log(3), value + 2 * omega(radius))
        best = max(best, value)
        heapq.heappush(queue, (-heuristic, counter, depth, box, radius))
        counter += 1
        evaluations += 1

    t0 = time.perf_counter()
    add(root, 0)
    for _ in range(splits):
        _, _, depth, box, _ = heapq.heappop(queue)
        k = int(np.argmax(box[:, 1] - box[:, 0]))
        mid = np.mean(box[k])
        left, right = box.copy(), box.copy()
        left[k, 1], right[k, 0] = mid, mid
        add(left, depth + 1)
        add(right, depth + 1)
    return {"splits": splits, "leaves": len(queue), "center_evaluations": evaluations,
            "best_center": best, "heuristic_upper_estimate": -queue[0][0],
            "minimum_leaf_l1_radius": min(row[4] for row in queue),
            "maximum_leaf_l1_radius": max(row[4] for row in queue),
            "maximum_depth": max(row[2] for row in queue), "seconds": time.perf_counter() - t0,
            "status": "exploratory only; floating centers are not interval-certified"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--basis-starts", type=int, default=64)
    parser.add_argument("--partition-starts", type=int, default=32)
    parser.add_argument("--splits", type=int, default=10000)
    parser.add_argument("--unitary-witness", default=None)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    data = json.loads((root / "generated/connes_stormer.json").read_text())
    c = max(data['n3']['cases'], key=lambda row: row['certified_gap'])
    raw_U = np.array(c['U_real']) + 1j * np.array(c['U_imag'])
    q, _, vh = np.linalg.svd(raw_U)
    U = q @ vh
    target_cayley = None
    if args.unitary_witness:
        from certify_points import cayley, deserialize
        target_cayley = json.loads(Path(args.unitary_witness).read_text())['unitary_cayley']
        exact_u = cayley(deserialize(target_cayley))
        U = np.array([[complex(float(z.re), float(z.im)) for z in row] for row in exact_u])
    print("case", c['index'], "historical partition", c['general'], "historical basis", c['basis'], flush=True)
    # Central finite differences check the independently written analytic gradient at one interior point.
    checks = {}
    for f, k in ((basis, 3), (frame, 6)):
        x = np.r_[np.linspace(.2, 1.2, k), np.linspace(.3, 5.1, k)]
        value, g = objective(x, U, f)
        fd = np.array([(objective(x + np.eye(len(x))[i] * 1e-6, U, f)[0]
                        - objective(x - np.eye(len(x))[i] * 1e-6, U, f)[0]) / 2e-6 for i in range(len(x))])
        checks[f.__name__] = float(np.max(np.abs(g - fd)))
        assert checks[f.__name__] < 1e-7, checks
    print("gradient checks", checks, flush=True)
    b = multi(U, basis, args.basis_starts, 20261103, 1200)
    print("new independent basis", b['best'], "seconds", b['seconds'], flush=True)
    p = multi(U, frame, args.partition_starts, 20261104, 1500)
    print("new four-element partition", p['best'], "seconds", p['seconds'], flush=True)
    gap = p['best'] - b['best']
    target_t = brentq(lambda t: 2 * omega(t) - gap, 1e-15, 2 / 3) if gap > 0 else None
    eps = target_t / 6 if target_t else None
    counts = ([math.ceil((math.pi / 2) / (2 * eps))] * 3
              + [math.ceil((2 * math.pi) / (2 * eps))] * 3) if eps else []
    cover = exploratory_cover(U, args.splits)
    print("cover exploration", cover, flush=True)
    result = {"timestamp_utc": datetime.now(timezone.utc).isoformat(), "python": platform.python_version(),
              "numpy": np.__version__, "scipy": scipy.__version__, "historical_case": c,
              "historical_partition_vectors_available": False,
              "source_note": "Historical JSON stores U and partition summary, not the partition vectors; new explicit frame reconstructed independently.",
              "target_unitary_numeric": serial_matrix(U),
              "target_minus_historical_numeric_norm": float(np.linalg.norm(U - raw_U)),
              "target_unitary_cayley": target_cayley,
              "gradient_check_max_abs": checks, "basis": b, "partition": p, "new_observed_gap": gap,
              "historical_state_search_value": data['n3']['G_star'][c['index']],
              "choda": entropy_entries(np.abs(U)**2) / 3, "universal_upper": math.log(3),
              "continuity_radius_T_for_full_gap": target_t, "per_coordinate_halfwidth": eps,
              "uniform_axis_cell_counts": counts, "uniform_cells": math.prod(counts) if counts else None,
              "exploratory_cover": cover,
              "certification_status": "No global certificate and no rigorous numerical lower enclosure; all new runs use float64/complex128."}
    (Path(__file__).resolve().parent / "basis_gap_results.json").write_text(json.dumps(result, indent=2))
    print("new observed gap", gap, "continuity T", target_t, "uniform cell count", result['uniform_cells'], flush=True)


if __name__ == '__main__':
    main()
