**Actual attempts on the higher-dimensional Connes–Størmer problem, 3 November 2026.**

These files are separate from the copied historical `generated/connes_stormer.json`. None of that historical
survey was overwritten or silently presented as a current run.

`explore_basis_gap.py` implements independent NumPy/SciPy local searches and a budgeted global-cover exploration.
The basis uses six CKM coordinates. The four-effect positive partition uses the first three rows of a U4
complex-Givens mesh; row orthonormality gives the partition identity. Both objectives use entrywise probabilities.
Their analytic gradients are checked against finite differences before the searches. Fixed seeds and every
start's status/value are recorded in JSON. Float64/complex128 calculations are exploratory, not global proofs.

`initial_polar_exploration.json` and `initial_polar_run.txt` record the initial campaign at the polar
approximation of historical U109. The historical JSON contains that U but **does not contain its partition
vectors**, so a new partition had to be reconstructed. `basis_gap_results.json` and `basis_gap_run.txt` record
the final campaign at the fixed exact rational Cayley unitary's numerical approximation.

`rational_point_witness.json` specifies Gaussian-rational skew-Hermitian Cayley parameters for U3, one U3
basis, and a U4 frame. These determine exact admissible matrices without trusting floating normalization.
`certify_points.py` reconstructs those matrices with Python Fraction arithmetic, checks unitarity and the
partition identity exactly, then evaluates the resulting rational-probability entropy expressions with Arb.
Its replay path imports neither NumPy/SciPy nor the algebra library. It certifies **point values only**.
Four negative checks reject a non-skew Cayley matrix, the wrong basis dimension and false pointwise claims;
their outcomes are recorded in `negative_checks.json`.
The checker explicitly refuses `python -O` and `python -OO`, preventing those modes from disabling its
admissibility assertions. The optimized-interpreter rejection is checked as well. `checker_sha256.txt` identifies
the final checked source.

From this article directory, replay the supplied exact witness:

```bash
/workspace/venvs/von-neumann/bin/python attempts/certify_points.py
```

On another machine use any Python environment with `python-flint`; replace the interpreter path accordingly.
The resulting `point_verification.json` contains enclosing balls and exact rational decimal endpoints.
The witness proves H(U0)>.572778446636, the single-basis value <.565919750583 and the point gap
>.006858696053. It does not prove that this basis is globally optimal. One normalized frame effect also gives
a certified single-state value >.754681285291; this is a lower bound for G*, not an upper bound for H.

To repeat the bounded final exploration (NumPy and SciPy additionally required):

```bash
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python attempts/explore_basis_gap.py \
  --basis-starts 64 --partition-starts 32 --splits 10000 \
  --unitary-witness attempts/rational_point_witness.json
```

The full two-stage regeneration first runs the same exploration without `--unitary-witness`, then
`python attempts/certify_points.py --generate`, then repeats the final exploration with that file and regenerates
the exact basis/frame witnesses with `--generate` once more. Regeneration is allowed to change the final
candidate matrices and last digits; validity is established by replay, not bitwise agreement of optimizers.

The actual continuity-cover exploration used10000splits,10001leaves and20001center evaluations. It did not
improve the analytic global cap log3. The center-based values are explicitly labelled heuristic estimates;
they are not a rigorous branch-and-bound certificate. The paper proves the entropy-continuity modulus and
reports the approximate3.44e26-cell resolution estimate for a crude uniform cover. This explains failure of
that particular attempt at the recorded budget, without asserting impossibility of a better method.

The separate `genericity.tex` proof does settle a mathematical question: Choda's partition is non-optimal for
Haar-almost every unitary in every n>=2. That proof does not rely on these searches.
