"""Exact rational Cayley witnesses and Arb entropy enclosures; no global maximum is certified."""
if not __debug__:
    raise RuntimeError("Point verification requires normal Python execution; -O and -OO are not supported")

from fractions import Fraction as F
from pathlib import Path
import argparse
import json
import math

from flint import arb, ctx


class Q:
    def __init__(self, re=0, im=0):
        self.re, self.im = F(re), F(im)

    @staticmethod
    def lift(other):
        return other if isinstance(other, Q) else Q(other)

    def __add__(self, other):
        other = self.lift(other)
        return Q(self.re + other.re, self.im + other.im)
    __radd__ = __add__

    def __neg__(self):
        return Q(-self.re, -self.im)

    def __sub__(self, other):
        return self + (-self.lift(other))

    def __mul__(self, other):
        other = self.lift(other)
        return Q(self.re * other.re - self.im * other.im,
                 self.re * other.im + self.im * other.re)
    __rmul__ = __mul__

    def __truediv__(self, other):
        other = self.lift(other)
        norm = other.re * other.re + other.im * other.im
        return self * Q(other.re / norm, -other.im / norm)

    def conj(self):
        return Q(self.re, -self.im)

    def abs2(self):
        return self.re * self.re + self.im * self.im

    def __eq__(self, other):
        other = self.lift(other)
        return self.re == other.re and self.im == other.im


def eye(n):
    return [[Q(int(i == j)) for j in range(n)] for i in range(n)]


def adj(a):
    return [[a[j][i].conj() for j in range(len(a))] for i in range(len(a[0]))]


def add(a, b, sign=1):
    return [[a[i][j] + sign * b[i][j] for j in range(len(a[0]))] for i in range(len(a))]


def mul(a, b):
    return [[sum((a[i][k] * b[k][j] for k in range(len(b))), Q())
             for j in range(len(b[0]))] for i in range(len(a))]


def inverse(a):
    n = len(a)
    x = [row[:] + identity for row, identity in zip(a, eye(n))]
    for k in range(n):
        pivot = next(i for i in range(k, n) if x[i][k] != 0)
        x[k], x[pivot] = x[pivot], x[k]
        v = x[k][k]
        x[k] = [z / v for z in x[k]]
        for i in range(n):
            if i != k:
                v = x[i][k]
                x[i] = [z - v * y for z, y in zip(x[i], x[k])]
    return [row[n:] for row in x]


def cayley(k):
    n = len(k)
    assert n in (3, 4) and all(len(row) == n for row in k)
    assert add(k, adj(k)) == [[Q() for _ in range(n)] for _ in range(n)]
    u = mul(add(eye(n), k, -1), inverse(add(eye(n), k)))
    assert mul(adj(u), u) == eye(n)
    return u


def ball(q):
    return arb(q.numerator) / arb(q.denominator)


def eta(q):
    assert q >= 0
    return arb(0) if q == 0 else -ball(q) * ball(q).log()


def value(u, x):
    z = mul(adj(u), x)
    return (sum((eta(a.abs2()) for row in z for a in row), arb(0))
            - sum((eta(a.abs2()) for row in x for a in row), arb(0))) / 3


def enclose_decimal(x, digits=12):
    scale = 10 ** digits
    lo, hi = math.floor(float(x) * scale), math.ceil(float(x) * scale)
    while not x > ball(F(lo, scale)):
        lo -= 1
    while not x < ball(F(hi, scale)):
        hi += 1
    return F(lo, scale), F(hi, scale)


def deserialize(k):
    return [[Q(re, im) for re, im in row] for row in k]


def verify(path):
    data = json.loads(Path(path).read_text())
    assert data['format'] == 'cs-rational-point-witness/1'
    ctx.prec = 256
    u = cayley(deserialize(data['unitary_cayley']))
    v = cayley(deserialize(data['basis_cayley']))
    w = cayley(deserialize(data['frame_cayley']))
    assert len(u) == len(v) == 3 and len(w) == 4
    frame = w[:3]
    assert mul(frame, adj(frame)) == eye(3)
    weights = [sum((frame[i][j].abs2() for i in range(3)), F(0)) for j in range(4)]
    assert all(t > 0 for t in weights)
    hp, hb = value(u, frame), value(u, v)
    rotated = mul(adj(u), frame)
    states = [(sum((eta(rotated[i][j].abs2() / weights[j]) for i in range(3)), arb(0))
               - sum((eta(frame[i][j].abs2() / weights[j]) for i in range(3)), arb(0))) for j in range(4)]
    state_index = max(range(4), key=lambda j: float(states[j]))
    state_lower, state_upper = enclose_decimal(states[state_index])
    l, upper_l = enclose_decimal(hp)
    b, upper_b = enclose_decimal(hb)
    if 'claims' in data:
        claims = data['claims']
        assert hp > ball(F(claims['partition_lower']))
        assert hp < ball(F(claims['partition_upper']))
        assert hb > ball(F(claims['basis_lower']))
        assert hb < ball(F(claims['basis_upper']))
    return {'precision_bits': ctx.prec, 'partition_ball': str(hp), 'basis_ball': str(hb),
            'partition_lower': str(l), 'partition_upper': str(upper_l),
            'basis_lower': str(b), 'basis_upper': str(upper_b),
            'point_gap_lower': str(l - upper_b),
            'state_index': state_index, 'state_ball': str(states[state_index]),
            'state_lower': str(state_lower), 'state_upper': str(state_upper),
            'scope': 'lower bound for H and enclosure at one basis; no global basis upper bound'}


def generate(results, output):
    # NumPy is used only to propose rational skew matrices. Verification above is exact + Arb.
    import numpy as np
    from explore_basis_gap import rotation

    result = json.loads(Path(results).read_text())

    def npmatrix(record):
        return np.array(record['real']) + 1j * np.array(record['imag'])

    def propose_cayley(u):
        n = len(u)
        k = (np.eye(n) - u) @ np.linalg.inv(np.eye(n) + u)
        k = (k - k.conj().T) / 2
        q = [[Q() for _ in range(n)] for _ in range(n)]
        for i in range(n):
            q[i][i] = Q(0, F(str(round(float(k[i, i].imag), 12))))
            for j in range(i + 1, n):
                q[i][j] = Q(F(str(round(float(k[i, j].real), 12))),
                            F(str(round(float(k[i, j].imag), 12))))
                q[j][i] = -q[i][j].conj()
        return [[[str(z.re), str(z.im)] for z in row] for row in q]

    params = result['partition']['parameters']
    w = np.eye(4, dtype=complex)
    for k, (i, j) in enumerate([(2, 3), (1, 2), (0, 1), (2, 3), (1, 2), (2, 3)]):
        w = w @ rotation(4, i, j, params[k], params[6+k])[0]
    data = {'format': 'cs-rational-point-witness/1', 'historical_case': 109,
            'unitary_cayley': result.get('target_unitary_cayley') or propose_cayley(
                npmatrix(result.get('target_unitary_numeric', result.get('U_polar')))),
            'basis_cayley': propose_cayley(npmatrix(result['basis']['matrix'])),
            'frame_cayley': propose_cayley(w),
            'rounding': 'skew-Hermitian Cayley parameters rounded to 12 decimal places',
            'scope': 'new exact rational unitary and frame seeded by historical case, not identical historical matrices'}
    Path(output).write_text(json.dumps(data, indent=2))
    verified = verify(output)
    data['claims'] = {k: verified[k] for k in ('partition_lower','partition_upper','basis_lower','basis_upper')}
    Path(output).write_text(json.dumps(data, indent=2))
    return verify(output)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--generate', action='store_true')
    parser.add_argument('--results', default='attempts/basis_gap_results.json')
    parser.add_argument('--witness', default='attempts/rational_point_witness.json')
    args = parser.parse_args()
    result = generate(args.results, args.witness) if args.generate else verify(args.witness)
    Path('attempts/point_verification.json').write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))
