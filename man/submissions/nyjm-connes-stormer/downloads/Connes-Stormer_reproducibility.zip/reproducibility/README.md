# Reproducibility supplement: Connes–Størmer entropy

Authors: Irina Nikolaeva and Andrej Novikov. Prepared 3 November 2026.

Affiliations: Lean Technologies Laboratory LLC (Irina Nikolaeva);
Novikov Laboratories LLC (Andrej Novikov).

The manuscript PDF is supplied separately. This supplement provides the exact
rational point witness, its checker, the independent exploratory searches,
and their recorded budgets/results.

## Exact point verification

From this directory, using Python 3.12 and python-flint 0.9.0:

```sh
python -m pip install -r requirements-verification.txt
python attempts/certify_points.py
```

The checker requires the standard library and python-flint only. It refuses
optimized Python because the exact-admissibility assertions must execute.
It checks rational Cayley unitaries and the Parseval-frame identity, then
encloses scalar entropies with Arb at 256-bit precision.

The pointwise partition value is a lower bound for the unrestricted entropy.
A checked upper endpoint for one basis is not a global upper bound over all
bases. The global basis comparison remains unproved; the recorded continuity
cover and its limitations are described in the manuscript.

## Exploratory search records

The attempts directory includes the fixed seeds, search budgets, optimizer
outputs and source program. Repeating search additionally needs the packages
in requirements-search.txt. Search values and centre evaluations are not
interval proof certificates. See attempts/README.md for the individual
commands and the distinction between historical and reconstructed inputs.

The code is distributed with the repository MIT notice; python-flint and
FLINT/Arb retain their own licences.
